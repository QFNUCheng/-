package com.example.campusnav;

import com.example.campusnav.cli.AppCLI;

/**
 * 应用程序主入口
 */
public class Main {
    public static void main(String[] args) {
        // 启动命令行界面
        new AppCLI().start();
    }
}
