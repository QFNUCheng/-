package com.example.campusnav.algorithm;

import com.example.campusnav.model.CampusGraph;
import com.example.campusnav.model.Location;
import com.example.campusnav.model.Path;

import java.util.*;

/**
 * 路径规划算法核心 (Dijkstra)
 */
public class PathFinder {

    public static class Result {
        public double totalDistance;
        public List<Location> pathNodes;

        public Result(double totalDistance, List<Location> pathNodes) {
            this.totalDistance = totalDistance;
            this.pathNodes = pathNodes;
        }
    }

    /**
     * 计算最短路径
     */
    public Result findShortestPath(Location start, Location end) {
        if (start == null || end == null) return null;
        if (start.equals(end)) return new Result(0, Arrays.asList(start));

        // 距离表
        Map<Location, Double> distances = new HashMap<>();
        // 前驱节点表（用于回溯路径）
        Map<Location, Location> predecessors = new HashMap<>();
        // 优先队列
        PriorityQueue<Location> queue = new PriorityQueue<>(Comparator.comparingDouble(distances::get));

        // 初始化
        List<Path> allPaths = CampusGraph.getInstance().getPaths();
        Set<Location> allNodes = new HashSet<>();
        for (Path p : allPaths) {
            allNodes.add(p.getFrom());
            allNodes.add(p.getTo());
        }

        for (Location node : allNodes) {
            distances.put(node, Double.MAX_VALUE);
        }
        distances.put(start, 0.0);
        queue.add(start);

        while (!queue.isEmpty()) {
            Location current = queue.poll();

            if (current.equals(end)) break;

            // 寻找邻居
            for (Path path : allPaths) {
                if (path.getFrom().equals(current)) {
                    Location neighbor = path.getTo();
                    double newDist = distances.get(current) + path.getDistance();

                    if (newDist < distances.get(neighbor)) {
                        distances.put(neighbor, newDist);
                        predecessors.put(neighbor, current);
                        queue.remove(neighbor); // 更新优先级
                        queue.add(neighbor);
                    }
                }
            }
        }

        // 回溯路径
        List<Location> path = new ArrayList<>();
        Location step = end;
        if (predecessors.get(step) == null && !start.equals(end)) {
            return null; // 无路可达
        }
        path.add(step);
        while (predecessors.get(step) != null) {
            step = predecessors.get(step);
            path.add(step);
        }
        Collections.reverse(path);

        return new Result(distances.get(end), path);
    }
}