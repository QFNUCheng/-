package com.example.campusnav.agent;

import com.example.campusnav.service.NavService;

import java.util.HashMap;
import java.util.Map;

/**
 * 智能代理 (模拟 LLM 意图识别)
 */
public class NavigationAgent {
    private final NavService service = new NavService();

    // 模拟关键词映射
    private final Map<String, String> intentMap = new HashMap<>();

    public NavigationAgent() {
        intentMap.put("吃饭", "食堂");
        intentMap.put("学习", "图书馆");
        intentMap.put("上课", "科技楼");
        intentMap.put("睡觉", "瀚海书院");
        intentMap.put("运动", "田径场");
        intentMap.put("办事", "行政楼");
    }

    /**
     * 处理自然语言输入
     */
    public String handleInput(String input) {
        input = input.trim();

        // 1. 直接导航指令 (包含 "去" 字)
        if (input.contains("去")) {
            // 简单解析：假设格式为 "从 A 去 B" 或 "去 B"
            String target = input.substring(input.indexOf("去") + 1).trim();
            // 去除语气词
            target = target.replace("。", "").replace("!", "").replace("！", "");

            // 检查是否是意图关键词
            String actualTarget = intentMap.getOrDefault(target, target);

            // 默认起点
            String start = "西门";
            if(input.contains("从")) {
                // 简单提取 "从" 和 "去" 之间的词
                int sIdx = input.indexOf("从") + 1;
                int eIdx = input.indexOf("去");
                if(sIdx < eIdx) {
                    start = input.substring(sIdx, eIdx).trim();
                }
            }

            return service.getNavigation(start, actualTarget);
        }

        // 2. 问候
        if (input.contains("你好") || input.contains("您好")) {
            return "你好！我是曲阜师大校园导航助手。你可以对我说：'我要从西门去图书馆' 或 '我要去吃饭'。";
        }

        return "我不太明白你的意思。请尝试说 '我要去[地点]' 或 '从[地点]去[地点]'。";
    }
}

