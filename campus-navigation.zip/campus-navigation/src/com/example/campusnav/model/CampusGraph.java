package com.example.campusnav.model;

import java.util.*;

/**
 * 校园地图数据仓库 (单例模式)
 */
public class CampusGraph {
    private final Map<String, Location> locations = new HashMap<>();
    private final List<Path> paths = new ArrayList<>();

    private static CampusGraph instance;

    private CampusGraph() {
        initMapData();
    }

    public static synchronized CampusGraph getInstance() {
        if (instance == null) {
            instance = new CampusGraph();
        }
        return instance;
    }

    // 初始化曲阜师范大学地图数据
    private void initMapData() {
        // 1. 添加地点
        Location westGate = addLoc("001", "西门", "大门");
        Location library = addLoc("002", "图书馆", "学习");
        Location techBuilding = addLoc("003", "科技楼", "教学楼");
        Location hanhai = addLoc("004", "瀚海书院", "宿舍");
        Location canteen = addLoc("005", "学生食堂", "餐饮");
        Location sportsField = addLoc("006", "田径场", "运动");
        Location adminBuilding = addLoc("007", "行政楼", "办公");

        // 2. 添加路径 (双向路径需添加两次或逻辑处理，这里简化为单向添加，算法中会处理连通性)
        // 西门 <-> 科技楼 (100米)
        addPath(westGate, techBuilding, 100);
        addPath(techBuilding, westGate, 100);

        // 科技楼 <-> 图书馆 (150米)
        addPath(techBuilding, library, 150);
        addPath(library, techBuilding, 150);

        // 西门 <-> 瀚海书院 (300米)
        addPath(westGate, hanhai, 300);
        addPath(hanhai, westGate, 300);

        // 瀚海书院 <-> 食堂 (50米)
        addPath(hanhai, canteen, 50);
        addPath(canteen, hanhai, 50);

        // 食堂 <-> 田径场 (200米)
        addPath(canteen, sportsField, 200);
        addPath(sportsField, canteen, 200);

        // 图书馆 <-> 行政楼 (100米)
        addPath(library, adminBuilding, 100);
        addPath(adminBuilding, library, 100);

        // 行政楼 <-> 田径场 (150米)
        addPath(adminBuilding, sportsField, 150);
        addPath(sportsField, adminBuilding, 150);
    }

    private Location addLoc(String id, String name, String type) {
        Location loc = new Location(id, name, type);
        locations.put(id, loc);
        return loc;
    }

    private void addPath(Location from, Location to, double dist) {
        paths.add(new Path(from, to, dist));
    }

    public Collection<Location> getAllLocations() {
        return locations.values();
    }

    public List<Path> getPaths() {
        return paths;
    }

    public Location findLocationByName(String name) {
        return locations.values().stream()
                .filter(l -> l.getName().contains(name))
                .findFirst()
                .orElse(null);
    }
}