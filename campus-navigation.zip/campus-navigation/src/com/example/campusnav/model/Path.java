package com.example.campusnav.model;

/**
 * 路径实体类 (Edge)
 */
public class Path {
    private final Location from;
    private final Location to;
    private final double distance; // 距离（米）

    public Path(Location from, Location to, double distance) {
        this.from = from;
        this.to = to;
        this.distance = distance;
    }

    public Location getFrom() { return from; }
    public Location getTo() { return to; }
    public double getDistance() { return distance; }
}
