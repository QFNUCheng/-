package com.example.campusnav.model;

/**
 * 地点实体类 (Node)
 */
public class Location {
    private final String id;
    private final String name;
    private final String type; // 如：教学楼、宿舍、食堂

    public Location(String id, String name, String type) {
        this.id = id;
        this.name = name;
        this.type = type;
    }

    public String getId() { return id; }
    public String getName() { return name; }
    public String getType() { return type; }

    @Override
    public String toString() {
        return name;
    }
}