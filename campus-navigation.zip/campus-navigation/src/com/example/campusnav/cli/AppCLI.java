package com.example.campusnav.cli;

import com.example.campusnav.agent.NavigationAgent;
import java.util.Scanner;

/**
 * 命令行交互界面
 */
public class AppCLI {
    private final NavigationAgent agent = new NavigationAgent();

    public void start() {
        Scanner scanner = new Scanner(System.in);
        System.out.println("🤖 欢迎使用曲阜师范大学智能导航助手 v1.0");
        System.out.println("💡 提示：输入 'exit' 退出程序");
        System.out.println("--------------------------------");

        // 打印欢迎语
        System.out.println(agent.handleInput("你好"));

        while (true) {
            System.out.print("\n👉 请输入指令: ");
            String input = scanner.nextLine();

            if ("exit".equalsIgnoreCase(input) || "quit".equalsIgnoreCase(input)) {
                System.out.println("👋 再见！祝你校园生活愉快。");
                break;
            }

            if (input.trim().isEmpty()) continue;

            // 调用 Agent 处理
            String response = agent.handleInput(input);
            System.out.println("\n" + response);
        }
        scanner.close();
    }
}