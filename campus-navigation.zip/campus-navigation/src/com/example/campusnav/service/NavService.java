package com.example.campusnav.service;

import com.example.campusnav.algorithm.PathFinder;
import com.example.campusnav.model.CampusGraph;
import com.example.campusnav.model.Location;
import com.example.campusnav.algorithm.PathFinder.Result;

/**
 * 业务逻辑层
 */
public class NavService {
    private final PathFinder finder = new PathFinder();
    private final CampusGraph graph = CampusGraph.getInstance();

    /**
     * 根据名称查询路径
     */
    public String getNavigation(String startName, String endName) {
        Location start = graph.findLocationByName(startName);
        Location end = graph.findLocationByName(endName);

        if (start == null) return "错误：找不到起点 [" + startName + "]";
        if (end == null) return "错误：找不到终点 [" + endName + "]";

        Result result = finder.findShortestPath(start, end);

        if (result == null) {
            return "抱歉，从 " + startName + " 到 " + endName + " 没有可行路径。";
        }

        StringBuilder sb = new StringBuilder();
        sb.append("🗺️ 规划成功！\n");
        sb.append("📍 起点：").append(startName).append("\n");
        sb.append("🏁 终点：").append(endName).append("\n");
        sb.append("📏 总距离：").append(String.format("%.0f", result.totalDistance)).append(" 米\n");
        sb.append("🚶 建议路线：\n");

        for (int i = 0; i < result.pathNodes.size(); i++) {
            sb.append("   ").append(i + 1).append(". ").append(result.pathNodes.get(i).getName());
            if (i < result.pathNodes.size() - 1) sb.append(" ->");
            sb.append("\n");
        }
        return sb.toString();
    }
}
